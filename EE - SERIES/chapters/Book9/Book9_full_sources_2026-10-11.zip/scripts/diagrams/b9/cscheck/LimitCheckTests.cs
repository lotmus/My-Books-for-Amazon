// Tests for Listing 35.5 (not a listing in the book).
using System.Globalization;
using System.Threading;
using BenchLimits;
using Xunit;

public class LimitCheckTests
{
    [Fact]
    public void GuardBandShrinksTheWindow()
    {
        var rail = new LimitCheck("3V3", 3.201, 3.399, 0.010);
        Assert.Equal(3.211, rail.TestLow, 9);
        Assert.Equal(3.389, rail.TestHigh, 9);
        Assert.False(rail.Passes(3.205));
        Assert.True(rail.Passes(3.300));
        Assert.False(rail.Passes(double.NaN));
    }

    [Fact]
    public void ThresholdOfTheSampleMosfetPasses()
    {
        var vth = new LimitCheck("Vth", 1.8, 2.5, 0.02);
        Assert.True(vth.Passes(2.161));
        Assert.False(vth.Passes(1.81));
    }

    [Fact]
    public void LogLineIgnoresGermanCulture()
    {
        Thread.CurrentThread.CurrentCulture = new CultureInfo("de-DE");
        var ron = new LimitCheck("Ron", 0.0, 1.5, 0.01);
        Assert.Equal("A123,Ron,1.113,0.01,1.49,PASS", ron.LogLine("A123", 1.113));
    }

    [Fact]
    public void RejectsWindowEatenByUncertainty()
    {
        Assert.Throws<System.ArgumentException>(() => new LimitCheck("x", 1.0, 1.1, 0.06));
    }
}
